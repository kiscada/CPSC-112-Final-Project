public class Location {
    
}
