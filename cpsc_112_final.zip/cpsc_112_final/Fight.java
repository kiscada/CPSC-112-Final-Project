public class Fight {
    
}
