import java.util.*;
import java.io.*;

public class Script {
    public HashMap<String, String> lines = new HashMap<String, String>();
    private static File scriptFile = new File("Script.txt");
    Scanner player = new Scanner(System.in);
    public String name = "";

    int health = 2;
    public boolean[] visited = new boolean[16];
    // ITEMS
    boolean candle = false;

    private void scriptSetup() throws FileNotFoundException {
        Scanner scriptScanner = new Scanner(scriptFile);
        String scriptString = "";
        while (scriptScanner.hasNext()) {
            scriptString = scriptString + " " + scriptScanner.next();
        }
        String[] scriptParagraph = scriptString.split(";");
        for (int i = 0; i < scriptParagraph.length; i+= 2) {
            lines.put(scriptParagraph[i].replaceAll("[^a-zA-Z]", ""), scriptParagraph[i+1].trim());
        }
    }

    public void intro() throws FileNotFoundException {
        scriptSetup();
        System.out.println(lines.get("Intro"));
        System.out.println("What is your name?");
        name = player.next();
        line();
        System.out.println("Hello, " + name);
        room1();
    }

    public void room1() {
        // entrace (not visited)
        if (!visited[1]) {
            System.out.println(lines.get("RoomOneEnter").replaceAll("@", name));
            visited[1] = true;
        }

        // candle
        if (!candle) {
                System.out.println(lines.get("RoomOneCandle").replaceAll("@", name));
                if (player.nextInt() == 1) {
                    line();
                    System.out.println("You picked up the candle.");
                    candle = true;
                    room2();
                }
        }

        // entrance (visited)
        if (visited[1]) {
            System.out.println(lines.get("RoomOneEnterB").replaceAll("@", name));
        }
        System.out.println("Do you want to visit Room 2?");
        if (player.nextInt() == 1) {
            room2();
        } else if (player.nextInt() == 2) {
            System.out.println("Okay");
        }
        
    }

    public void room2() {
        if (!visited[2]) {
            System.out.println(lines.get("RoomTwoEnter").replaceAll("@", name));
        }
        // choose next room
        System.out.println("Do you want to visit Room 1?");
        if (player.nextInt() == 1) {
            line();
            room1();
            System.out.print("hi");
        } else if (player.nextInt() == 2) {
            System.out.println("OkayOkay");
        }
    }

    public static void line() {
        System.out.println();
    }


}
