import java.io.FileNotFoundException;
import java.util.*;
import java.io.*;

public class Story {
    Script script = new Script();

    public static void main(String[] args) throws FileNotFoundException {
        Script script = new Script();
        script.intro();
    }
    
    
}